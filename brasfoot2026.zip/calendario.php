<?php
require_once 'classes/Database.class.php';
require_once 'classes/Partida.php';
require_once 'classes/Campeonato.php';
require_once 'classes/Save.php';
require_once 'classes/User.class.php';

session_start();

$save = new Save();
$save_ativo = $save->buscarAtivo();
$id_save = $save_ativo['id'] ?? 1;

$partidaModel = new Partida();
$campeonatoModel = new Campeonato();

$campeonatos = $campeonatoModel->listar($id_save);

// Definir campeonato selecionado (Padrão: o do time do usuário)
$id_camp_selecionado = $_GET['id_camp'] ?? null;
if (!$id_camp_selecionado && $save_ativo['clube_id']) {
    $stmt = Database::getInstance()->getConnection()->prepare("SELECT campeonato_id FROM classificacao WHERE time_id = ? AND id_save = ? LIMIT 1");
    $stmt->execute([$save_ativo['clube_id'], $id_save]);
    $id_camp_selecionado = $stmt->fetchColumn();
}
// Se ainda não tiver, pega o primeiro
if (!$id_camp_selecionado && !empty($campeonatos)) {
    $id_camp_selecionado = $campeonatos[0]['id'];
}

$partidas = $id_camp_selecionado ? $partidaModel->listarPorCampeonato($id_camp_selecionado, null, $id_save) : [];
$camp_atual = $id_camp_selecionado ? $campeonatoModel->buscarPorId($id_camp_selecionado) : null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['simular'])) {
    $partida_id = $_POST['partida_id'];
    $resultado = $partidaModel->simular($partida_id);
    if ($resultado) {
        $mensagem = "Partida simulada: {$resultado['gols_casa']} x {$resultado['gols_fora']}";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendário - Fenix Foot</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --glass: rgba(255, 255, 255, 0.05);
            --glass-border: rgba(255, 255, 255, 0.1);
            --primary: #00d2ff;
            --secondary: #3a7bd5;
            --accent: #ff007a;
            --text: #ffffff;
        }
        * { margin:0; padding:0; box-sizing:border-box; font-family: 'Outfit', sans-serif; }
        body { background: #050505; color: var(--text); padding: 40px 20px; }
        .header { text-align: center; margin-bottom: 40px; }
        .header h1 { font-size: 2.5em; font-weight: 800; letter-spacing: -1px; margin-bottom: 10px; }
        
        .container { max-width: 1000px; margin: 0 auto; }
        
        .selector-box { 
            background: var(--glass); 
            backdrop-filter: blur(20px); 
            padding: 20px; 
            border-radius: 20px; 
            border: 1px solid var(--glass-border);
            margin-bottom: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 20px;
        }
        
        select { 
            background: #111; 
            color: white; 
            padding: 12px 20px; 
            border-radius: 12px; 
            border: 1px solid var(--glass-border);
            outline: none;
            font-size: 1em;
            min-width: 300px;
        }
        
        .btn { background: var(--primary); color: #000; padding: 12px 25px; text-decoration: none; border-radius: 12px; font-weight: 700; border: none; cursor: pointer; transition: 0.3s; }
        .btn:hover { background: white; transform: translateY(-2px); }
        .btn-back { background: transparent; color: var(--primary); border: 1px solid var(--primary); }

        table { width:100%; border-collapse:collapse; margin-top:20px; background: var(--glass); border-radius: 25px; overflow: hidden; border: 1px solid var(--glass-border); }
        th, td { padding:18px; text-align:left; border-bottom:1px solid var(--glass-border); }
        th { background: rgba(255,255,255,0.05); color: var(--primary); font-weight: 600; text-transform: uppercase; font-size: 0.8em; letter-spacing: 2px; }
        
        .match-row:hover { background: rgba(255,255,255,0.02); }
        .team-name { font-weight: 600; font-size: 1.1em; }
        .score { font-weight: 800; font-size: 1.2em; color: var(--accent); background: rgba(255,0,122,0.1); padding: 5px 15px; border-radius: 10px; min-width: 60px; text-align: center; display: inline-block; }
        
        .rodada-badge { background: var(--secondary); color: white; padding: 4px 10px; border-radius: 8px; font-size: 0.8em; font-weight: 700; }
        
        .alert { background: rgba(46, 204, 113, 0.2); border: 1px solid #2ecc71; color:#2ecc71; padding:15px; border-radius:15px; margin-bottom: 20px; text-align:center; }
    </style>
    <script src="js/audio.js"></script>
</head>
<body>
    <div class="header">
        <h1>📅 Calendário Oficial</h1>
        <p style="opacity:0.6; font-weight:300;">Temporada 2026 - Gestão Profissional</p>
    </div>
    
    <div class="container">
        <?php if (isset($mensagem)): ?>
            <div class="alert"><?php echo htmlspecialchars($mensagem); ?></div>
        <?php endif; ?>

        <div class="selector-box">
            <label style="font-weight:600; color:var(--primary);">CAMPEONATO:</label>
            <form method="GET" style="display:flex; gap:10px;">
                <select name="id_camp" onchange="this.form.submit()">
                    <?php foreach ($campeonatos as $c): ?>
                        <option value="<?php echo $c['id']; ?>" <?php echo $id_camp_selecionado == $c['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($c['nome']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </form>
            <a href="index.php" class="btn btn-back">Painel Inicial</a>
        </div>

        <?php if ($camp_atual): ?>
            <h2 style="margin-bottom:20px; font-weight:800; color:var(--primary);"><?php echo htmlspecialchars($camp_atual['nome']); ?></h2>
            
            <?php if (empty($partidas)): ?>
                <div class="selector-box" style="padding:40px;">
                    <p>Nenhuma partida agendada para este campeonato.</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Rodada</th>
                            <th>Data/Hora</th>
                            <th>Confronto</th>
                            <th>Resultado</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($partidas as $p): ?>
                        <tr class="match-row">
                            <td><span class="rodada-badge"><?php echo $p['rodada']; ?>ª</span></td>
                            <td style="font-size:0.9em; opacity:0.7;">
                                <?php echo date('d/m/Y', strtotime($p['data_partida'])); ?><br>
                                <?php echo $p['hora']; ?>
                            </td>
                            <td>
                                <span class="team-name"><?php echo htmlspecialchars($p['time_casa_nome']); ?></span>
                                <span style="margin:0 10px; opacity:0.3;">vs</span>
                                <span class="team-name"><?php echo htmlspecialchars($p['time_fora_nome']); ?></span>
                            </td>
                            <td style="text-align:center;">
                                <?php if ($p['jogada']): ?>
                                    <span class="score"><?php echo $p['gols_casa']; ?> x <?php echo $p['gols_fora']; ?></span>
                                <?php else: ?>
                                    <span style="opacity:0.3;">Aguardando</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (!$p['jogada']): ?>
                                    <a href="partida_ao_vivo.php?id=<?php echo $p['id']; ?>" class="btn" style="padding:8px 15px; font-size:0.8em;">JOGAR ⚽</a>
                                <?php else: ?>
                                    <a href="partida_ao_vivo.php?id=<?php echo $p['id']; ?>" class="btn btn-back" style="padding:8px 15px; font-size:0.8em;">DETALHES</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>
